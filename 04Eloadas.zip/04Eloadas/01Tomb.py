szo1="alma"
szo2="körte"
szo3="szilva"
szo4="barack"
szo5="datolya"

gyumolcsok=["alma","körte","szilva","barack","datolya"]
print(gyumolcsok)
print(len(gyumolcsok))
print(f"A gyümölcsök tömb 3. eleme: {gyumolcsok[3]}")

gyumolcsok2=[]
gyumolcsok2.append("alma")
gyumolcsok2.append("körte")
gyumolcsok2.append("szilva")
gyumolcsok2.append("barack")
gyumolcsok2.append("datolya")
print(gyumolcsok2)