print("Add meg 5 zöldség nevét és én eltárolom egy kollekcióban!")
zoldsegek=[]
for i in range(5):
    zoldseg=input("Add meg egy zöldség nevét! ")
    zoldsegek.append(zoldseg)
print(zoldsegek)
